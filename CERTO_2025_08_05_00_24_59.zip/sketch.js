let campoFantasia, campoHumor, campoMelodrama, campoRomance, campoAção, campoClássico;

function setup() {
  createCanvas(800, 400);
  createSpan("Sua idade: ").position(10, 10);
  createElement("h2", "Recomendador de filmes").position(250,15);
  campoIdade = createInput("5");
  campoIdade.position(100, 10);

  campoFantasia = createCheckbox("Gosta de fantasia?", false).position(10, 40);
  campoHumor = createCheckbox("Gosta de humor?", false).position(10, 60);
  campoMelodrama = createCheckbox("Gosta de melodrama?", false).position(10, 80);
  campoRomance = createCheckbox("Gosta de romance?", false).position(10, 100);
  campoAção = createCheckbox("Gosta de ação?", false).position(10, 120);
  campoClássico = createCheckbox("Gosta de clássico?", false).position(10, 140);
}

function draw() {
  background("rgb(0,210,255)");

  let idade = int(campoIdade.value());
  let gostaDeFantasia = campoFantasia.checked();
  let gostaDeHumor = campoHumor.checked();
  let gostaDeMelodrama = campoMelodrama.checked();
  let gostaDeRomance = campoRomance.checked();
  let gostaDeAção = campoAção.checked();
  let gostaDeClássico = campoClássico.checked();

  let recomendacao= geraRecomendacao(idade,gostaDeFantasia,gostaDeHumor,gostaDeAção,gostaDeMelodrama,gostaDeClássico,gostaDeRomance);

  fill(color("black"));
  textAlign(CENTER, CENTER);
  textSize(26);
  text("Filme recomendado:", width / 2, height / 2 - 30);
  textSize(32);
  text(recomendacao, width / 2, height / 2 + 10);
}

function geraRecomendacao(idade, gostaDeFantasia, gostaDeHumor, gostaDeAção, gostaDeMelodrama, gostaDeClássico, gostaDeRomance) {
  
  if (idade >= 16) { 
    if(gostaDeAção || gostaDeHumor) return "Bad boys para sempre"
    
    else return "Nenhum filme recomendado"
    
    }
  
  else if (idade >= 14){
    if(gostaDeFantasia || gostaDeRomance) return "Ghost: do outro lado da vida"
    
    else return "Nenhum filme recomendado"
    
    }
  
  else if (idade >= 13){
      if(gostaDeFantasia || gostaDeAção) return "Guardiões das galaxias"
      
      else return "Nenhum filme recomendado"
    }
  
  else if (idade < 13){
      if(gostaDeFantasia || gostaDeHumor) return "A fantástica fábrica de chocolate"
      
      else if(gostaDeMelodrama || gostaDeClássico) return "A vida é bela"
      
      else  return "Nenhum filme recomendado"
      
    }
  
  else{
    return "Nenhum filme recomendado"
    
    }
      
  }
    
    